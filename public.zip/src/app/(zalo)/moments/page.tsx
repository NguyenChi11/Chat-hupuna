import ComingSoonPage from '@/components/ComingSoonPage';

const page = () => {
  return (
    <div>
      <ComingSoonPage />
    </div>
  );
};

export default page;
