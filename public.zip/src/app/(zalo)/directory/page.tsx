import ComingSoonPage from '@/components/ComingSoonPage';
import React from 'react';

const page = () => {
  return (
    <div>
      <ComingSoonPage />
    </div>
  );
};

export default page;
