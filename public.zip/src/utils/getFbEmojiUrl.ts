export function getEmojiUrl(unicode: string) {
  return `https://cdn.jsdelivr.net/gh/twitter/twemoji/assets/72x72/${unicode}.png`;
}
